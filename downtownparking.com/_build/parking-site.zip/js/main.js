var parking = {};  // namespace
