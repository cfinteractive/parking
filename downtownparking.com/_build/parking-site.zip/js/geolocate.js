/* Relies on sort.js functions */
$(function() {
  parking.getLocationNearMe();
});

