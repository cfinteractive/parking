/* Relies on sort.js functions */
$(function() {
  parking.sortLotsByName();
});
